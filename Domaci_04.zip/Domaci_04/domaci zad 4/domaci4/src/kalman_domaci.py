#! /usr/bin/env python3
import rospy
import tf
import numpy as np
import pandas as pd
import sys
import math as m
from scipy.linalg import block_diag 
from threading import Thread
import time
from std_msgs.msg import Float64MultiArray

from geometry_msgs.msg import Pose
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan
from sensor_msgs.msg import JointState
from laser_line_extraction.msg import LineSegment,LineSegmentList
from tf.transformations import euler_from_quaternion, quaternion_from_euler

global M_procitano, M



# Funkcija za predikciju sledećeg stanja i kovarijacione matrice
def transitionFunction(x_1, P_1, U, b):
    
    d_sr = U[0]  # Pređeni put desnog točka
    d_sl = U[1]  # Pređeni put levog točka
    teta = x_1[2]  # Ugao
    k1 = (d_sl + d_sr) / 2  # Srednja vrednost pređenog puta
    k2 = (d_sr - d_sl) / 2 / b  # Polovina razlike pređenog puta podeljena sa bazom

    x_pred = x_1 + np.array([k1 * np.cos(teta + k2), k1 * np.sin(teta + k2), k2]).reshape(3, 1)  # Predikcija stanja
    teta_pom = x_pred[2]  # Novi ugao
    Fx = np.array([[1, 0, -k1 * np.sin(teta_pom + k2)], [0, 1, k1 * np.cos(teta_pom + k2)], [0, 0, 1]])  # Jakobijan funkcije prelaza stanja
    
    Fu = np.zeros([3, 2])  # Jakobijan funkcije prelaza sa ulazom
    Fu[0, 0] = np.cos(teta_pom + k2) / 2 + np.sin(teta_pom + k2) * k1 / 2 / b 
    Fu[0, 1] = np.cos(teta_pom + k2) / 2 - np.sin(teta_pom + k2) * k1 / 2 / b  
    Fu[1, 0] = np.sin(teta_pom + k2) / 2 - np.cos(teta_pom + k2) * k1 / 2 / b 
    Fu[1, 1] = np.sin(teta_pom + k2) / 2 + np.cos(teta_pom + k2) * k1 / 2 / b  
    Fu[2, 0] = -1 / b  
    Fu[2, 1] = 1 / b  

    k = 0.01  # Faktor za skaliranje kovarijacije procesnog šuma
    Q = np.array([[k * abs(d_sr), 0], [0, k * abs(d_sl)]])  # Kovarijacija procesnog šuma
    P_pred = np.dot(np.dot(Fx, P_1), np.transpose(Fx)) + np.dot(np.dot(Fu, Q), np.transpose(Fu))  # Predikcija kovarijacione matrice

    return x_pred, P_pred  # Vraćanje predikcije stanja i kovarijacione matrice
	
# Funkcija za izračunavanje predikcije merenja i Jakobijana
def measurementFunction(x_pred, m_i):
    
    [x, y, teta] = x_pred  # Dekodiranje stanja
    [ro, alfa] = m_i  # Parametri linije (zida)
    z_pred = np.array([alfa - teta, ro - (x * np.cos(alfa) + y * np.sin(alfa))])  # Predikcija merenja
    H_pred = np.array([[0, 0, -1], [-np.cos(alfa), -np.sin(alfa), 0]])  # Jakobijan funkcije merenja
    
    return z_pred, H_pred  # Vraćanje predikcije merenja i Jakobijana
	
# Funkcija za asocijaciju merenja sa predikcijom stanja
def associateMeasurement(x_pred, P_pred, Z, R, M, g):
    
    H_pred = np.empty((np.shape(M)[1], 2, 3))  # Prealociranje nizova
    V = np.empty((np.shape(M)[1], np.shape(Z)[1], 2))
    Sgm = np.empty((np.shape(M)[1], np.shape(Z)[1], 2, 2))
    
    for i in range(np.shape(M)[1]):
        [z_pred, H_pred_i] = measurementFunction(x_pred, M[:, i])  # Izračunavanje predikcije merenja i Jakobijana
        H_pred[i, :, :] = H_pred_i  # Čuvanje Jakobijana
        
        for j in range(np.shape(Z)[1]):
            z = Z[:, j].reshape(2, 1)  # Merenje
            V[i, j, :] = np.ravel(z - z_pred)  # Razlika između stvarnog merenja i predikcije
            Sgm[i, j, :, :] = np.dot(np.dot(H_pred_i, P_pred), np.transpose(H_pred_i)) + R[j, :, :]  # Kovarijacija razlike

    V_novo = []  # Lista za nove vrednosti razlike
    H_novo = []  # Lista za nove Jakobijane
    R_novo = []  # Lista za nove kovarijacije
    
    for i in range(np.shape(V)[0]):
        for j in range(np.shape(V)[1]):
            dij = np.dot(np.dot(np.transpose(V[i, j, :]), np.linalg.inv(Sgm[i, j, :, :])), V[i, j, :])  # Mahalanobis rastojanje
            if(dij < g**2):  # Ako je Mahalanobis rastojanje manje od praga
                V_novo.append(V[i, j, :])  
                R_novo.append(R[j, :, :]) 
                H_novo.append(H_pred[i, :, :])  
    V_novo = np.array(V_novo, dtype=float)  
    R_novo = np.array(R_novo, dtype=float)  
    H_novo = np.array(H_novo, dtype=float) 
    
    return V_novo, H_novo, R_novo  # Vraćanje novih vrednosti
	
# Kalman filter korak ažuriranja
def filterStep(x_pred, P_pred, V, H_pred, R):
    
    P_pred = P_pred.astype(float)  
    R = block_diag(*R)  # Kreiranje blok dijagonalne matrice za šum merenja
    H = np.reshape(H_pred, (-1, 3))  
    V = np.reshape(V, (-1, 1))  

    S = np.dot(np.dot(H, P_pred), np.transpose(H)) + R  # Inovaciona kovarijacija
    K = np.dot(np.dot(P_pred, np.transpose(H)), np.linalg.inv(S))  # Kalmanov dobitak

    xt = x_pred + np.dot(K, V)  # Ažuriranje stanja
    Pt = np.dot((np.eye(3) - np.dot(K, H)), P_pred)  # Ažuriranje kovarijacije
    return xt, Pt  # Vraćanje novog stanja i kovarijacije

# Callback funkcija za laserska merenja
def callback_laser(data):
    
    global Z, R, M_procitano, M
    linije = data.line_segments  # Linijski segmenti iz laserskog skenera
    Z_pom = []
    R_pom = []
    
    for i, linija u enumerate(linije):
        Z_pom.append(np.array([linija.angle, linija.radius]))  # Dodavanje ugla i radijusa u merenja
        covariance = np.asarray(linija.covariance)  # Kovarijacija
        R_pom.append(covariance.reshape((2, 2)))  

    Z = np.transpose(np.array(Z_pom))  
    R = np.array(R_pom)  
    if (M_procitano == 0):
        M_procitano = 1  # Merenja očitana
	

# Callback funkcija 
def callback_odom(data):
    
    global X_odom, P_odom, U, b
    covariance = data.pose.covariance  
    P_odom_temp = np.array(covariance)  
    idx = [0, 1, 5, 6, 7, 11, 30, 31, 35]
    P_odom = P_odom_temp[idx].reshape((3, 3))  
    pose = data.pose.pose.position  # Pozicija
    orient = data.pose.pose.orientation  # Orijentacija
    _, _, theta = euler_from_quaternion([orient.x, orient.y, orient.z, orient.w])  
    X_odom = np.array([pose.x, pose.y, theta]).T  # Postavljanje pozicije i ugla u stanje

    T = 1. / 30  # Vremenski korak
    v = data.twist.twist.linear.x  # Linearna brzina
    w = data.twist.twist.angular.z  # Ugaona brzina
    v_l = v - w * b  # Brzina levog točka
    v_r = v + w * b  # Brzina desnog točka
    U[0] = U[0] + T * v_r  # Ažuriranje pređenog puta desnog točka
    U[1] = U[1] + T * v_l  # Ažuriranje pređenog puta levog točka

if __name__ == '__main__':
    b = 0.16  # Baza (rastojanje između točkova)
    g = 0.1  # Prag za asocijaciju merenja

    Z = []  # Merenja
    R = []  # Kovarijacija merenja
    U = np.zeros((2, 1))  # Ulazi (pređeni putevi točkova)
    P_odom = np.empty((3, 3))  # Kovarijacija odometrije
    X_odom = np.empty((3, 1))  # Stanje odometrije

    rospy.init_node('domaci4', anonymous=True)  # Inicijalizacija ROS čvora
    sub1 = rospy.Subscriber("line_segments", LineSegmentList, callback_laser) 
    sub2 = rospy.Subscriber("odom", Odometry, callback_odom)  
    pub = rospy.Publisher('kalman', Float64MultiArray, queue_size=1)  # Publisher za Kalman filter

    X = np.array([[0], [0], [0]])  # Inicijalno stanje
    P = np.eye(3) / 10  # Inicijalna kovarijacija (mala vrednost za početnu sigurnost)

    M_procitano = 0  # Oznaka da merenja nisu očitana
    while M_procitano == 0:
        M = []  # Prazan niz za merenja
    M = Z  # Postavljanje merenja

    print(M)  # Ispis merenja

    while True:
        X_preth = X  # Prethodno stanje
        P_preth = P  # Prethodna kovarijacija

        [xt, Pt] = transitionFunction(X_preth, P_preth, U, b)  # Predikcija stanja i kovarijacije
        [V_novo, H_novo, R_novo] = associateMeasurement(xt, Pt, Z, R, M, g)  # Asocijacija merenja
        X, P = filterStep(xt, Pt, V_novo, H_novo, R_novo)  # Ažuriranje stanja i kovarijacije
        if X[2] > np.pi:  # Normalizacija ugla u opseg -pi do pi
            pom = np.round(X[2] / (np.pi * 2))
            X[2] = X[2] - np.pi * 2 * pom
        if X[2] > np.pi:  # Normalizacija ugla u opseg -pi do pi
            pom = np.round(X[2] / (np.pi * 2))  # Izračunavanje koliko puta je ugao veći od 2*pi
            X[2] = X[2] - np.pi * 2 * pom  # Normalizacija ugla
        if X[2] < (-np.pi):  # Ako je ugao manji od -pi
            pom = np.round(-X[2] / (np.pi * 2))  # Izračunavanje koliko puta je ugao manji od -2*pi
            X[2] = X[2] + np.pi * 2 * pom  # Normalizacija ugla

        rospy.loginfo('Pozicija odom')  # Ispisivanje informacije o poziciji iz odometrije
        rospy.loginfo(X_odom)  # Ispisivanje stanja iz odometrije
        rospy.loginfo('Pozicija Kalman')  # Ispisivanje informacije o poziciji iz Kalmanovog filtera
        rospy.loginfo(X)  # Ispisivanje stanja iz Kalmanovog filtera

        rospy.loginfo('Kovarijaciona odom')  # Ispisivanje informacije o kovarijaciji iz odometrije
        rospy.loginfo(P_odom)  # Ispisivanje kovarijacione matrice iz odometrije
        rospy.loginfo('Kovarijaciona Kalman')  # Ispisivanje informacije o kovarijaciji iz Kalmanovog filtera
        rospy.loginfo(P)  # Ispisivanje kovarijacione matrice iz Kalmanovog filtera

        U = np.zeros((2, 1))  # Resetovanje pređenog puta za novu periodu
        pub.publish(Float64MultiArray(data=np.array([X[0][0], X[1][0], X[2][0]])))  # Slanje podataka preko publishera
        time.sleep(0.5)  # Pauza od 0.5 sekundi pre sledećeg ciklusa
		
		
