#! /usr/bin/env python3
import rospy
import tf
import numpy as np
import pandas as pd
import sys
import math as m
from scipy.linalg import block_diag 
from threading import Thread
import time
from std_msgs.msg import Float64MultiArray

from geometry_msgs.msg import Pose
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan
from sensor_msgs.msg import JointState
from laser_line_extraction.msg import LineSegment,LineSegmentList
from tf.transformations import euler_from_quaternion, quaternion_from_euler

global M_procitano, M



# Funkcija za predikciju sledećeg stanja i kovarijacione matrice
def transitionFunction(x_1, P_1, U, b):
    d_sr = U[0]  # Pređeni put desnog točka
    d_sl = U[1]  # Pređeni put levog točka
    teta = x_1[2]  # Ugao
    k1 = (d_sl + d_sr) / 2  # Srednja vrednost pređenog puta
    k2 = (d_sr - d_sl) / 2 / b  # Polovina razlike pređenog puta podeljena sa bazom

    # Predikcija stanja
    x_pred = x_1 + np.array([k1 * np.cos(teta + k2), k1 * np.sin(teta + k2), k2]).reshape(3, 1)  
    teta_pom = x_pred[2]  # Novi ugao
    Fx = np.array([[1, 0, -k1 * np.sin(teta_pom + k2)], [0, 1, k1 * np.cos(teta_pom + k2)], [0, 0, 1]])  # Jakobijan funkcije prelaza stanja
    Fu = np.zeros([3, 2])  # Jakobijan funkcije prelaza sa ulazom
    Fu[0, 0] = np.cos(teta_pom + k2) / 2 + np.sin(teta_pom + k2) * k1 / 2 / b  
    Fu[0, 1] = np.cos(teta_pom + k2) / 2 - np.sin(teta_pom + k2) * k1 / 2 / b  
    Fu[1, 0] = np.sin(teta_pom + k2) / 2 - np.cos(teta_pom + k2) * k1 / 2 / b  
    Fu[1, 1] = np.sin(teta_pom + k2) / 2 + np.cos(teta_pom + k2) * k1 / 2 / b  
    Fu[2, 0] = -1 / b  
    Fu[2, 1] = 1 / b  

    k = 0.01  # Faktor za skaliranje kovarijacije procesnog šuma
    Q = np.array([[k * abs(d_sr), 0], [0, k * abs(d_sl)]])  # Kovarijacija procesnog šuma
    P_pred = np.dot(np.dot(Fx, P_1), np.transpose(Fx)) + np.dot(np.dot(Fu, Q), np.transpose(Fu))  # Predikcija kovarijacione matrice

    return x_pred, P_pred  # Vraćanje predikcije stanja i kovarijacione matrice

	
# Funkcija za izračunavanje predikcije merenja i Jakobijana
def measurementFunction(x_pred, m_i):
    
    [x, y, teta] = x_pred  # Dekodiranje stanja
    [ro, alfa] = m_i  # Parametri linije (zida)
    z_pred = np.array([alfa - teta, ro - (x * np.cos(alfa) + y * np.sin(alfa))])  # Predikcija merenja
    H_pred = np.array([[0, 0, -1], [-np.cos(alfa), -np.sin(alfa), 0]])  # Jakobijan funkcije merenja
    
    return z_pred, H_pred  # Vraćanje predikcije merenja i Jakobijana
	
# Funkcija za asocijaciju merenja sa predikcijom stanja
def associateMeasurement(x_pred, P_pred, Z, R, M, g):
    
    H_pred = np.empty((np.shape(M)[1], 2, 3))  
    V = np.empty((np.shape(M)[1], np.shape(Z)[1], 2))
    Sgm = np.empty((np.shape(M)[1], np.shape(Z)[1], 2, 2))
    
    for i in range(np.shape(M)[1]):
        [z_pred, H_pred_i] = measurementFunction(x_pred, M[:, i])  # Izračunavanje predikcije merenja i Jakobijana
        H_pred[i, :, :] = H_pred_i  # Čuvanje Jakobijana
        for j in range(np.shape(Z)[1]):
            z = Z[:, j].reshape(2, 1)  # Merenje
            V[i, j, :] = np.ravel(z - z_pred)  # Razlika između stvarnog merenja i predikcije
            Sgm[i, j, :, :] = np.dot(np.dot(H_pred_i, P_pred), np.transpose(H_pred_i)) + R[j, :, :]  # Kovarijacija razlike

    V_novo = []  # Lista za nove vrednosti razlike
    H_novo = []  # Lista za nove Jakobijane
    R_novo = []  # Lista za nove kovarijacije
    
    for i in range(np.shape(V)[0]):
        for j in range(np.shape(V)[1]):
            
            dij = np.dot(np.dot(np.transpose(V[i, j, :]), np.linalg.inv(Sgm[i, j, :, :])), V[i, j, :])  # Mahalanobisova distanca
            if dij < g**2:  # Provera da li distanca zadovoljava prag
            
                V_novo.append(V[i, j, :])
                R_novo.append(R[j, :, :])
                H_novo.append(H_pred[i, :, :])
                
    V_novo = np.array(V_novo, dtype=float)  
    R_novo = np.array(R_novo, dtype=float)  
    H_novo = np.array(H_novo, dtype=float)  

    return V_novo, H_novo, R_novo  # Vraćanje novih vrednosti

# Funkcija za filtriranje koraka
def filterStep(x_pred, P_pred, V, H_pred, R):
    
    P_pred = P_pred.astype(float)  
    R = block_diag(*R)  # Kreiranje blok dijagonalne matrice
    H = np.reshape(H_pred, (-1, 3)) 
    V = np.reshape(V, (-1, 1)) 

    S = np.dot(np.dot(H, P_pred), np.transpose(H)) + R  # Izračunavanje S matrice
    K = np.dot(np.dot(P_pred, np.transpose(H)), np.linalg.inv(S))  # Izračunavanje Kalmanovog dobitka

    xt = x_pred + np.dot(K, V)  # Ažuriranje stanja
    Pt = np.dot((np.eye(3) - np.dot(K, H)), P_pred)  # Ažuriranje kovarijacione matrice
    
    return xt, Pt  # Vraćanje ažuriranog stanja i kovarijacione matrice

# Callback funkcija za laserski skener
def callback_laser(data):
    
    global Z, R, M_procitano, M  
    linije = data.line_segments  # Čitanje linija iz laserskog skenera
    Z_pom = []  # Lista za merenja
    R_pom = []  # Lista za kovarijacije
    
    for i, linija in enumerate(linije):
        Z_pom.append(np.array([linija.angle, linija.radius]))  # Dodavanje merenja u listu
        covariance = np.asarray(linija.covariance)  # Pretvaranje kovarijacije u niz
        R_pom.append(covariance.reshape((2, 2)))  # Dodavanje kovarijacije u listu

    Z = np.transpose(np.array(Z_pom))  # Pretvaranje liste u niz i transponovanje
    R = np.array(R_pom)  # Pretvaranje liste u niz
    if M_procitano == 0:  # Provera da li su inicijalna merenja već očitana
        M_procitano = 1  # Postavljanje flag-a da su inicijalna merenja očitana
	

# Callback funkcija za odometriju
def callback_odom(data):
    
    global X_odom, P_odom, U, b  # Globalne promenljive
    covariance = data.pose.covariance  # Čitanje kovarijacije pozicije
    P_odom_temp = np.array(covariance)  
    idx = [0, 1, 5, 6, 7, 11, 30, 31, 35]  # Indeksi relevantnih vrednosti u kovarijacionoj matrici
    P_odom = P_odom_temp[idx].reshape((3, 3))  # Kreiranje 3x3 kovarijacione matrice
    pose = data.pose.pose.position  # Čitanje pozicije
    orient = data.pose.pose.orientation  # Čitanje orijentacije
    _, _, theta = euler_from_quaternion([orient.x, orient.y, orient.z, orient.w])  
    X_odom = np.array([pose.x, pose.y, theta]).T  # Kreiranje vektora stanja

    T = 1. / 30  # Vremenski period
    v = data.twist.twist.linear.x  # Linearna brzina
    w = data.twist.twist.angular.z  # Ugaona brzina
    v_l = v - w * b  # Brzina levog točka
    v_r = v + w * b  # Brzina desnog točka
    U[0] = U[0] + T * v_r  # Ažuriranje pređenog puta desnog točka
    U[1] = U[1] + T * v_l  # Ažuriranje pređenog puta levog točka

# Glavna funkcija
if __name__ == '__main__':
    b = 0.16  # Razmak između točkova
    g = 0.1  # Prag za asocijaciju merenja

    Z = []  # Niz za merenja
    R = []  # Niz za kovarijacije merenja
    U = np.zeros((2, 1))  # Niz za pređeni put
    P_odom = np.empty((3, 3))  # Prazna matrica za kovarijaciju odometrije
    X_odom = np.empty((3, 1))  # Prazan vektor za stanje odometrije

    rospy.init_node('domaci4', anonymous=True)  # Inicijalizacija ROS noda
    sub1 = rospy.Subscriber("line_segments", LineSegmentList, callback_laser)  # Subscribovanje na topic za linije iz laserskog skenera
    sub2 = rospy.Subscriber("odom", Odometry, callback_odom)  # Subscribovanje na topic za odometriju
    pub = rospy.Publisher('kalman', Float64MultiArray, queue_size=1)  # Kreiranje publishera za topic 'kalman'

    X = np.array([[0], [0], [0]])  # Inicijalno stanje
    P = np.eye(3) / 10  # Inicijalna kovarijaciona matrica (mali broj jer smo sigurni da smo u početnoj poziciji)

    M_procitano = 0  # Flag za provere inicijalnih merenja
    while M_procitano == 0:
        M = []  # Čeka dok se ne očitaju inicijalna merenja
    M = Z  # Postavlja inicijalna merenja

    print(M)  # Ispis inicijalnih merenja

    while True:  # Glavna petlja
        X_preth = X  # Čuva prethodno stanje
        P_preth = P  # Čuva prethodnu kovarijacionu matricu

        [xt, Pt] = transitionFunction(X_preth, P_preth, U, b)  # Predikcija sledećeg stanja i kovarijacione matrice
        [V_novo, H_novo, R_novo] = associateMeasurement(xt, Pt, Z, R, M, g)  # Asocijacija merenja sa predikcijom stanja
        X, P = filterStep(xt, Pt, V_novo, H_novo, R_novo)  # Ažuriranje stanja i kovarijacione matrice Kalmanovim filtrom
        if X[2] > np.pi:  # Da bi ugao bio u opsegu -pi do pi
            pom = np.round(X[2] / (np.pi * 2))
            X[2] = X[2] - np.pi * 2 * pom
        if X[2] < (-np.pi):
            pom = np.round(-X[2] / (np.pi * 2))
            X[2] = X[2] + np.pi * 2 * pom

        rospy.loginfo('Pozicija odom')  # Loguje poziciju iz odometrije
        rospy.loginfo(X_odom)  # Loguje poziciju iz odometrije
        rospy.loginfo('Pozicija Kalman')  # Loguje poziciju iz Kalmanovog filtra
        rospy.loginfo(X)  # Loguje poziciju iz Kalmanovog filtra
        
        rospy.loginfo('Kovarijaciona odom')  # Loguje kovarijaciju iz odometrije
        rospy.loginfo(P_odom)  # Loguje kovarijaciju iz odometrije
        rospy.loginfo('Kovarijaciona Kalman')  # Loguje kovarijaciju iz Kalmanovog filtra
        rospy.loginfo(P)  # Loguje kovarijaciju iz Kalmanovog filtra
        
        U = np.zeros((2, 1))  # Resetuje pređeni put za novu periodu
        pub.publish(Float64MultiArray(data=np.array([X[0][0], X[1][0], X[2][0]])))  # Publishuje trenutno stanje
        time.sleep(0.5)  # Pauza od 0.5 sekundi
		
		
		
		
