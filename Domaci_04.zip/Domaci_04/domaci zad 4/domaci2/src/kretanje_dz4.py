#!/usr/bin/env python3

import rospy
import math
#import csv
#import tf
import numpy as np
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist
from std_msgs.msg import Int64, Float64
from std_msgs.msg import Float64MultiArray

from domaci2.srv import servis, servisResponse
global x,y, theta
def response_callback(req):
    val = Twist()
    
    if(req.rezim==0): #ruchni rezim
        brzina_lin = 0.3
        brzina_ugao = np.pi/2
        
        if(req.napred==1): #kretanje je unapred
            val.linear.x = brzina_lin
        elif(req.napred==0): #kretanje unazad
            val.linear.x = -brzina_lin
        elif(req.napred==2): #stoji
            val.linear.x = 0
        if(req.rotiranje==1): #treba da rotira
            val.angular.z = brzina_ugao
        elif(req.rotiranje==0):
            val.angular.z = 0
    
        pub.publish(val)
    
    if(req.rezim==1): #automathski rezim
        global x, y, theta
        ro = 50
        thetac = 50
        while(ro>0.05)or(abs(thetac-theta)>0.157):
            xc = req.x_cilj
            yc = req.y_cilj
            thetac = req.theta_cilj
            
        
            delta_x = xc-x
            delta_y = yc-y
            ro = np.sqrt((delta_x)**2 + (delta_y)**2)
            alfa = -theta + np.arctan2(delta_y,delta_x)
            beta = -(theta + alfa) + thetac
        
            k_ro = 0.5
            k_a = 0.8
            k_b = -0.2
            
            if(alfa>np.pi/2) or (alfa<-np.pi/2): # kad je iza
                v = -k_ro*ro
                alfa = alfa - np.pi*np.sign(alfa)
                beta = beta - np.pi*np.sign(beta)              
                w = k_a*alfa + k_b*beta
                

            else: # kad je ispred
                v = k_ro*ro
                w = k_a*alfa + k_b*beta
                
        
            if(ro>0.25):
                odnos = abs(v/w)
                v = 0.3*np.sign(v)
                w = 0.3/odnos*np.sign(w)
       
            val.linear.x = v
            val.angular.z = w
            
            pub.publish(val)
            
        val.linear.x = 0
#        while (abs(thetac-theta)>0.314):
#            val.angular.z = np.pi/2
#            pub.publish(val)
        val.angular.z = 0
        pub.publish(val)
    return servisResponse(True)
            
def odom_callback(req):
    global x, y, theta
    q_x = req.pose.pose.orientation.x
    q_y = req.pose.pose.orientation.y
    q_z = req.pose.pose.orientation.z
    q_w = req.pose.pose.orientation.w
    
    theta = np.arctan2(2.0*(q_w*q_z + q_x*q_y), 1.0 - 2.0*(q_y**2 + q_z**2))
    x = req.pose.pose.position.x
    y = req.pose.pose.position.y
    
def kalman_callback(req):
    rospy.loginfo('Kalman usao')
    global x, y, theta
    x = req.data[0]
    y = req.data[1]
    theta = req.data[2]
    
    
    

rospy.init_node('kretanje', anonymous=True)
sub = rospy.Subscriber('kalman',Float64MultiArray ,kalman_callback)
pub = rospy.Publisher('/cmd_vel', Twist, queue_size = 10)
#sub = rospy.Subscriber('/odom', Odometry, odom_callback)

s = rospy.Service('servis', servis, response_callback)
rospy.loginfo('Service is ready!')
rospy.spin()

