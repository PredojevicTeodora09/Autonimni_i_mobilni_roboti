#!/usr/bin/env python3

import rospy
import math
#import csv
#import tf
import numpy as np
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist
from std_msgs.msg import Int64, Float64

from domaci2.srv import servis, servisResponse

# Definisanje callback funkcije za odgovor na zahtev servisa
def response_callback(req):
    
    # Inicijalizacija poruke za komande kretanja
    # Poruke koje će se objavljivati su tipa Twist, 
    # što znači da će sadržati informacije o linearnom i rotacionom kretanju robota.
    val = Twist()
    
    # Provera da li je zahtev u rucnom rezimu
    if(req.rezim==0): 
        # Postavljanje brzine kretanja i rotacije za rucni rezim
        brzina_lin = 0.7
        brzina_ugao = np.pi
        
        # Postavljanje linearnog kretanja u napred, nazad ili stajanje
        if(req.napred==1): 
            val.linear.x = brzina_lin
        elif(req.napred==0): 
            val.linear.x = -brzina_lin
        elif(req.napred==2): 
            val.linear.x = 0
        
        # Postavljanje rotacije ako je potrebno rotirati
        if(req.rotiranje==1): 
            val.angular.z = brzina_ugao
        else:
            val.angular.z = 0
    
        # Objavljivanje poruke komande kretanja
        pub.publish(val)
        
    # Automatski rezim
    if(req.rezim==1): 
        
        global x, y, theta
        ro = 50
        thetac = 50
        
        # Petlja se izvršava dok robot ne stigne do cilja
        while(ro>0.05) or (abs(thetac-theta)>0.157):
            
            # Dobijanje koordinata cilja
            xc = req.x_cilj
            yc = req.y_cilj
            thetac = req.theta_cilj
            
            # Računanje razlike između trenutne i ciljane pozicije
            delta_x = xc - x
            delta_y = yc - y
            
            # Računanje udaljenosti do cilja
            ro = np.sqrt((delta_x)**2 + (delta_y)**2)
            
            # Računanje orijentacije prema cilju
            alfa = -theta + np.arctan2(delta_y, delta_x)
            beta = -(theta + alfa) + thetac
            
            # Postavljanje koeficijenata za kontroler kretanja
            k_ro = 0.5
            k_a = 0.8
            k_b = -0.2
            
            # Ako je cilj iza robota
            if(alfa > np.pi/2) or (alfa < -np.pi/2):
                v = -k_ro*ro
                alfa = alfa - np.pi*np.sign(alfa)
                beta = beta - np.pi*np.sign(beta)              
                w = k_a*alfa + k_b*beta
            # Ako je cilj ispred robota
            else:
                v = k_ro*ro
                w = k_a*alfa + k_b*beta
            
            # Ako je udaljenost do cilja veća od određene vrednosti
            if(ro > 0.25):
                odnos = abs(v/w)
                v = 0.3*np.sign(v)
                w = 0.3/odnos*np.sign(w)
            
            # Postavljanje linearnih i rotacionih brzina
            val.linear.x = v
            val.angular.z = w
            
            # Objavljivanje poruke sa komandama kretanja
            pub.publish(val)
            
        # Kada robot stigne do cilja, postavlja se brzina na 0
        val.linear.x = 0
        val.angular.z = 0
        pub.publish(val)
    
    # Vracanje odgovora servisu da je zahtev obradjen uspesno
    return servisResponse(True)


# Inicijalizacija ROS node-a
rospy.init_node('kretanje', anonymous=True)

# Postavljanje objekta za publikaciju komandi kretanja
pub = rospy.Publisher('/cmd_vel', Twist, queue_size = 10)

# Postavljanje servisa za komunikaciju sa spoljnim komponentama
# Definisan je da koristi poruku servis za zahtev i servisResponse za odgovor
s = rospy.Service('servis', servis, response_callback)

# Prikaz poruke o spremnosti servisa
rospy.loginfo('Service is ready!')

rospy.spin()
