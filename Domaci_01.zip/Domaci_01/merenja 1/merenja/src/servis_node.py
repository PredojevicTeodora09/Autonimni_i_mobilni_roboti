#!/usr/bin/env python3

import rospy
import csv
from merenja.srv import servis, servisResponse   # Uvoz servisa koji je definiran u paketu "merenja"
from std_msgs.msg import String
from std_msgs.msg import Float32

# Callback funkcija koja se poziva kada se zatraži servis 'servis'.
def response_callback(req):

    # Otvaramo CSV datoteku za dodavanje novih podataka (append mode)
    with open('weather_data_nyc_centralpark_2016.csv', 'a+') as file1:
        # Kreiranje objekta pisca
        writer = csv.writer(file1, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
        
        # Zapisivanje novih podataka u CSV datoteku
        writer.writerow([str(req.Max *1.8+32.0), str(req.Min *1.8+32.0), str(req.Avr *1.8+32.0)])
        
        # Objavljivanje novih podataka na temu 'servis_obrada'
        pub.publish(req.Max *1.8+32.0)
        pub.publish(req.Min *1.8+32.0+200.0)
        pub.publish(req.Avr *1.8+32.0+500.0)  
              
    # Vraćanje odgovora na servis - True ako je servis uspešno izvršen
    return servisResponse(True)
    
# Inicijalizacija ROS čvora s imenom 'servis_node'
rospy.init_node('servis_node', anonymous = False)

# Kreiranje izdavača za temu 'servis_obrada'
pub = rospy.Publisher('servis_obrada', Float32, queue_size = 10)

# Kreiranje servisa 'servis' sa callback funkcijom 'response_callback'
s = rospy.Service('servis', servis, response_callback)
# Ispis uz pomoc ROS log da je servis spreman za upotrebu
rospy.loginfo('Service is ready!')
rospy.spin()
