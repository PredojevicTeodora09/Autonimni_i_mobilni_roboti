#!/usr/bin/env python3

import rospy

from std_msgs.msg import String
from std_msgs.msg import Float32

# Callback funkcija koja se poziva kad se primi nova poruka na temi 'obrada_prikaz'.
def callback(data):
    # Ispis prosečne temperature u Celzijusima pomocu ROS log funkcije.
    rospy.loginfo(' Prosecna temperatura u C je %s', data.data)
    
# Glavna funkcija listener koja pretplatom na temu 'obrada_prikaz' prima i obrađuje poruke.
def listener():
    # Inicijalizacija ROS čvora s imenom 'prikaz'
    rospy.init_node('prikaz', anonymous = False)
    # Pretplata na temu 'obrada_prikaz' kako bi se primale prosečne temperature
    rospy.Subscriber('obrada_prikaz', Float32, callback)
    rospy.spin()

if __name__ == '__main__':
    try:
    # Poziv funkcije listener
        listener()
    except rospy.ROSInterruptException:
        pass
    
