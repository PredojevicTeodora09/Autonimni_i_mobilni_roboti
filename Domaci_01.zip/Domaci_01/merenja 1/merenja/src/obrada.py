#!/usr/bin/env python3

import rospy
from std_msgs.msg import Float32
from std_msgs.msg import Int32
      
# Callback funkcija koja se poziva kad se primi nova poruka na temi 'merenje_obrada' ili 'servis_obrada'.
def callback(data):    
# Ova funkcija obrađuje primljene podatke i izvršava odgovarajuće akcije.

    # Ako je primljena temperatura manja od 150.0 (pretpostavka da je u Fahrenheitima),	
    if (data.data < 150.0):
    # Pretvaranje temperature u Celzijuse
        global maks1
        maks1 = (data.data -32.0)/1.8
    
    # Ako je temperatura između 150.0 i 450.0 (pretpostavka u Fahrenheitima),
    elif (data.data < 450.0):
        global mini1
        mini1 = (data.data - 200.0 -32.0)/1.8
        # Izračunavanje oscilacija temperature
        oscilacije = maks1 - mini1
        if (oscilacije > 15.0):      # Ako su oscilacije veće od 15.0, objavi akciju na temi 'obrada_akcija' (1 za akciju).
            pub_akcija.publish(1)
            
    # Ako je temperatura veća od 450.0 (opet pretpostavka u Fahrenheitima),
    else:
        global srednja1
        srednja1 = (data.data - 500.0 -32.0)/1.8
        # Objavljivanje srednje temperature na temi 'obrada_prikaz'
        pub_prikaz.publish(srednja1)
        rospy.loginfo(srednja1)  # Ispis srednje temperature pomocu ROS log funkcije kako bismo mogli da poredimo sta se salje i stize na nod obrada.

    
if __name__=='__main__':
    try:
    
        # Inicijalizacija ROS čvora s imenom 'obrada'
        rospy.init_node('obrada', anonymous = False)
        
        # Pretplata na temu 'merenje_obrada' kako bi se primale temperature(u Fahrenheitima)
        sub = rospy.Subscriber('merenje_obrada', Float32, callback)
        
        # Pretplata na temu 'servis_obrada' kako bi se primale druge vrste podataka
        sub_servis = rospy.Subscriber('servis_obrada', Float32, callback)
        
        # Objavljivanje srednje temperature na temi 'obrada_prikaz'
        pub_prikaz = rospy.Publisher('obrada_prikaz', Float32, queue_size = 10)
        
        # Objavljivanje akcije na temi 'obrada_akcija'
        pub_akcija = rospy.Publisher('obrada_akcija', Int32, queue_size = 10)
   
        rospy.spin()
         # Postavljanje brzine petlje (loop rate) na 10 iteracija u sec
        r = rospy.Rate(10)
        
    except rospy.ROSInterruptException:
        pass
 
