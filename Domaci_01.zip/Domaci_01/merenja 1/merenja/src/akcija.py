#!/usr/bin/env python3

import rospy
from std_msgs.msg import Int32

# Globalna promenljiva za brojanje akcija
global brojac

# Callback funkcija koja se poziva kada se primi nova poruka na temi 'obrada_akcija'
def callback(data):
    global brojac
    # Povećaj brojač svaki put kad se primi poruka
    brojac = brojac+1
     # Ispis brojača na terminalu uz pomoc ROS log funkcije
    rospy.loginfo(brojac)
    
# Glavna funkcija listener koja pretplatom na temu 'obrada_akcija' prima i obrađuje poruke.    
def listener():
    # Inicijalizacija ROS čvora sa imenom 'akcija'
    rospy.init_node('akcija', anonymous = False)
    # Pretplata na temu 'obrada_akcija' kako bi se primale akcije
    rospy.Subscriber('obrada_akcija', Int32, callback)
    global brojac
    brojac = 0
    rospy.spin()
    
if __name__=='__main__':
    try:
    # Poziv funkcije listener
        listener()
    except ROSInterruptException:
        pass
