#!/usr/bin/env python3

import rospy
import csv
from std_msgs.msg import String
from std_msgs.msg import Float32

# Definicija funkcije talker() koja će se koristiti za objavljivanje poruka.
def talker():

    # Kreiranje objekta izdavača (Publisher) koji će objavljivati poruke na ROS topiku 'merenje_obrada'.
    # Poruke koje će se objavljivati će biti tipa Float32.
    pub = rospy.Publisher('merenje_obrada', Float32, queue_size = 10)
    
    # Inicijalizacija ROS čvora (node) s imenom 'merenje'.
    # Postavljanje anonymous na False znači da se neće dodavati slučajni broj na kraj imena čvora.
    rospy.init_node('merenje', anonymous = False)
    
    r = rospy.Rate(10) # 10 iteracija u sekundi.
    
    with open('weather_data_nyc_centralpark_2016.csv', 'r') as file:
    # Otvaramo CSV datoteku 'weather_data_nyc_centralpark_2016.csv' sa with open u režimu čitanja ('r'),
    # što osigurava da će se datoteka automatski zatvoriti nakon završetka rada s njom.
    
        reader = csv.reader(file)
        # Kreiranje objekta reader za čitanje sadržaja CSV datoteke.
        
        j = 0
        for i in reader:
        # Petlja koja prolazi kroz redove CSV datoteke.
        
            if (j>0): 
            # Preskačemo prvi red CSV datoteke koji sadrži zaglavlje.
               
                maks = float(i[1])
                mini = float(i[2])+200.0
                srednja = float(i[3])+500.0
                # Čitanje vrijednosti maksimalne, minimalne i srednje temperature iz trenutnog reda CSV datoteke.
                
                pub.publish(maks) 
                pub.publish(mini)
                pub.publish(srednja)
                # Objavljivanje maksimalne, minimalne i srednje temperature na ROS temu.\
                
            j = 1 # za preskakanje prve iteracije
            r.sleep()
            # Pauziranje petlje kako bi se održala brzina petlje od 10 iteracija u sekundi.
        
if __name__=='__main__':
    try:
        talker()
        # Ispis obavestenja kada se posalju svi podaci pomocu ROS log funkcije.
        rospy.loginfo(' Poslati su podaci! ')
    except rospy.ROSInterruptException:
        pass
        # Poziv funkcije talker(). U slučaju prekida iz ROS-a, hvata se izuzetak rospy.ROSInterruptException kako bi se izbeglo prekidanje programa.
        
        
